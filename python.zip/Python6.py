x = int(input("Kolik chcete zadat známek?"))
seznam_znamek = []

for i in range(x):
    a = int(input("Zapište známku:"))
    while True:
        if 0 < a <= 5:
            seznam_znamek.append(a)
            break
        else: 
            print("Známka není na škále od 1 do 5.")
            a = int(input("Zapište jinou známku:"))

print("Vaše zadané známky jsou:", seznam_znamek)

def vypocet_prumeru(seznam_znamek):
    soucet = sum(seznam_znamek)
    vysledek = soucet / x
    print("Pruměr vašich známek je:", vysledek)
    return(vysledek)

prumer = vypocet_prumeru(seznam_znamek)

if prumer >= 3:
    print("Je co zlepšovat")
else:
    print("Skvělá práce")