txt = "Ahoj"
print(len(txt))
if txt[2] == "o":
    print("třetí je o")
for i in range(len(txt)):
    print (txt[i])